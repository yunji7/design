<?php
	/**
	 * Created by PhpStorm.
	 * User: android
	 * Date: 2015/8/8
	 * Time: 16:14
	 */

class A{

}

	$A = new A();

	$A->x = 5;
	echo $A->x;

	$B = new A();
	var_dump($B);